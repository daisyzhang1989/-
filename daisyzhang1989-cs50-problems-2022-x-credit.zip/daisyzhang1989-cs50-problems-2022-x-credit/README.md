https://vscode.dev/
URLをクリック
「」を選択
